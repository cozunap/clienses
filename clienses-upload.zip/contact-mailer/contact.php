<?php
/**
 * Clienses Contact Mailer
 * ========================
 * PHP mailer script — runs natively on HostGator (Apache + PHP).
 * Upload this folder to public_html alongside your Next.js static export.
 *
 * SETUP: Edit the $recipient variable below with your email address.
 */

// ── CONFIG ──────────────────────────────────────────────────────────────────
$recipient  = "contacto@clienses.com"; // <-- Cambia a tu correo
$from_name  = "Clienses Contact System";
$from_email = "noreply@clienses.com";   // <-- Usa un email de tu dominio
$subject    = "Nueva Consulta Estratégica — Clienses";
// ────────────────────────────────────────────────────────────────────────────

// ── CORS: Allow requests from your own domain ────────────────────────────────
$allowed_origins = [
    "https://clienses.com",
    "https://www.clienses.com",
    "http://localhost:3000",  // Remove this line in production
];

$origin = $_SERVER["HTTP_ORIGIN"] ?? "";
if (in_array($origin, $allowed_origins)) {
    header("Access-Control-Allow-Origin: $origin");
}
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

// Handle preflight OPTIONS request
if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

// ── Only accept POST ─────────────────────────────────────────────────────────
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed."]);
    exit();
}

// ── Read JSON body ────────────────────────────────────────────────────────────
$input = json_decode(file_get_contents("php://input"), true);

if (!$input) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid request body."]);
    exit();
}

// ── Sanitize & Validate ───────────────────────────────────────────────────────
function sanitize($value) {
    return htmlspecialchars(trim(strip_tags($value ?? "")), ENT_QUOTES, "UTF-8");
}

$name   = sanitize($input["name"]   ?? "");
$email  = sanitize($input["email"]  ?? "");
$phone  = sanitize($input["phone"]  ?? "");
$intent = sanitize($input["intent"] ?? "");

if (empty($name) || empty($email) || empty($phone) || empty($intent)) {
    http_response_code(400);
    echo json_encode(["error" => "Todos los campos son obligatorios."]);
    exit();
}

if (!filter_var(filter_var($email, FILTER_SANITIZE_EMAIL), FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(["error" => "Dirección de email inválida."]);
    exit();
}

// ── Build the email ───────────────────────────────────────────────────────────
$email_body = "
════════════════════════════════════════
  NUEVA CONSULTA ESTRATÉGICA — CLIENSES
════════════════════════════════════════

NOMBRE / EMPRESA:
  {$name}

EMAIL:
  {$email}

TELÉFONO:
  {$phone}

INTENCIÓN ESTRATÉGICA:
  {$intent}

════════════════════════════════════════
Mensaje recibido el: " . date("Y-m-d H:i:s T") . "
IP: " . ($_SERVER["REMOTE_ADDR"] ?? "desconocida") . "
";

$headers  = "From: {$from_name} <{$from_email}>\r\n";
$headers .= "Reply-To: {$name} <{$email}>\r\n";
$headers .= "X-Mailer: PHP/" . phpversion() . "\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

// ── Send ──────────────────────────────────────────────────────────────────────
$sent = mail($recipient, $subject, $email_body, $headers);

if ($sent) {
    http_response_code(200);
    echo json_encode(["success" => true, "message" => "Mensaje enviado correctamente."]);
} else {
    http_response_code(500);
    echo json_encode(["error" => "No se pudo enviar el mensaje. Intente nuevamente."]);
}
