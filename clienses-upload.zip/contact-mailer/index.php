<?php
// Block direct browser access to this folder
http_response_code(403);
echo "Access denied.";
exit();
